ONE Beta 10
===========

Project Lead
------------
Karl Hobley (karl@turbodog.co.uk)


Developed By
------------
BlitzWerks (www.turbodog.co.uk)



Controls
--------

WASD - Move
Mouse - Look
left mouse button - fire
right mouse button - aim
ctrl - duck
shift - sprint
r - reload


Instructions on how to change the displaymode
---------------------------------------------

1. Open preferences.txt
2. Change 'Preferences_DisplayWidth' and 'Preferences_DisplayHeight' to the displaymode you want to view this demo in
3. Save


Instructions on how to update
-----------------------------

1. Run ONE.exe
2. Click update in the bottom right
3. Wait a few secconds, if there are updates available, they will be listed on the screen
4. Click install
5. Wait for the updates to download, this may take a few minutes
6. When the updates have finnished installing, the application will close.
7. Wait a few secconds for the Updates to install, when they are finnished, a message will pop up saying that its done.

(c)BlitzWerks 2008